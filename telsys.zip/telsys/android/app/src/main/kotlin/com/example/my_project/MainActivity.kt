package com.mycompany.telkes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
